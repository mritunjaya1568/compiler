#include<stdio.h>

//Single Line Comment
/*Multi
Line Comment
*/

int main(){
    float var1 =    2.34;
    float   var2 =    67;
    float ans   = var1 + var2;
    return 0;
}
