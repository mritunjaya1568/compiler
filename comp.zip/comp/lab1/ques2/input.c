#include <stdio.h>

int glov = 7;


int main(){
	int toolonglonglonglonglonglonglonglonglong = 23;
	int abcrty = 12345;
	int bgy = 23;
	float ddddiu = 123.0;

}
